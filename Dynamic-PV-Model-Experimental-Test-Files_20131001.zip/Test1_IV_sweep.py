# Test 2 of 3 - PV I-V Sweep
# Measures PV Current-Voltage Characteristics
# Katherine A. Kim
# Special thanks to Boris Dieseldorf his help with Python
# University of Illinois at Urbana-Champaign
# 1/31/2013
# Physical Setup: Function Generator with transformer and Oscilliscope

# open file for saving data
I = open("I.dat","w")
V = open("V.dat","w")

# setup communication with instrument
from visa import*
import time
## import datetime

#Check connections with instruments
SrcMeter = instrument("GPIB::2")        # Keithley 2420 SourceMeter
print "Equipment:"                      # confirm connection, ask for it's name
print SrcMeter.ask('*IDN?')

start = time.time()     #start timing from this point

# configure meter for current mode
SrcMeter.write('*RST')                  #Reset GPIB Defaults
SrcMeter.write(':SOUR:FUNC CURR')       #Set current mode
SrcMeter.write(':SOUR:CURR:MODE FIX')
SrcMeter.write(':SOUR:CURR:RANG 0.5')   #Set acceptable current range
SrcMeter.write(':SENS:FUNC "VOLT"')     #Set-up voltage measurement
SrcMeter.write(':SENS:VOLT:PROT 30')    #Set acceptable voltage range
SrcMeter.write(':SYST:RSEN ON')     #Turn on 4-wire sensing

# Current Measurement Points
Iset = range(500,-400,-2) #Desired testing range in mA
print Iset

SrcMeter.write(':SOUR:CURR:LEV 0')
SrcMeter.write(':OUTP ON')

# set and then measure I and V for each point
for Ival in Iset:
    Ival_fl = float(Ival)/1000  #convert into A
##     print ' '                   #new line in output
##     print str(Ival_fl)
    
    SrcMeter.write(':SOUR:CURR:LEV '+str(Ival_fl))      #Set meter I value
    #time.sleep(0.01)           #wait momentarily to let system settle
    
    meterout = SrcMeter.ask(':READ?')   #Read back string
    meterV = float(meterout[0:13])      #first measurement is voltage
    meterI = float(meterout[14:27])     #second measurement is current

##     # Debugging: print-out values
##     print meterout
##     print 'V: '+str(meterV)
##     print 'I: '+str(meterI)

    # Store values in text file with space deliminator
    I.write(str(meterI)+' ')
    V.write(str(meterV)+' ')
    #end for loop
    
SrcMeter.write(":OUTP OFF")     #Turn off the source output

I.close()
V.close()

# Display elapsed time
print "Elapsed time(s):"
print (time.time() - start)
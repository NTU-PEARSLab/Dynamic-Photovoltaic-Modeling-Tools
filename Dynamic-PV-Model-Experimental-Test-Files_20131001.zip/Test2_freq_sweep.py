# Test 2 of 3 - PV Frequency Sweep
# Finds Rs and Ls values
# Katherine A. Kim
# Special thanks to Boris Dieseldorf his help with Python
# University of Illinois at Urbana-Champaign
# 1/31/2013
# Physical Setup: Function Generator with transformer and Oscilliscope

# setup communication with instrument
from visa import*
import time

#Check connections with instruments
FreqGen = instrument("GPIB::1")         # Agilent 33250A Function Generator
print "Equipment GPIB 1:"               # confirm connection, ask for it's name
print FreqGen.ask('*IDN?')

OScope = instrument("USB0::0x0699::0x0401::C000784")        #Tekronix MSO4034
print "Equipment USB:"                  # confirm connection, ask for it's name
print OScope.ask('*IDN?')

# configure meter for current mode

FreqGen.write('*RST')                  #Reset GPIB Defaults


## # 50 Hz Current Sweep for PV
## FreqGen.write('APPL:SIN 50, 1, 0')       #Set current mode

## # open file for saving data
## I = open('freq_i.dat','w')
## V = open('freq_v.dat','w')

##FreqGen.write('SWEep:SPACing{LOGarithmic}') 

start = time.time()     #start timing from this point

# Current Measurement Points
fset = [500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 300000,500000, 1000000, 2000000, 3000000]
print fset

## SrcMeter.write(':OUTP ON')
## SrcMeter.ask(':READ?')   #Read back string
## SrcMeter.write(':SOUR:CURR:LEV 0')      #Set meter I value

## index = 1;

FreqGen.write('OUTPut ON')      # Turn on function generator
for fval in fset:
##     print ' '
    FreqGen.write('APPL:SIN '+str(fval)+', 5.0, 0')  
    
    #OScope.write(':CH2:OFFS '+str(-Ival_fl)) #Adjust the Ch2 offset to center at zero
##     print 1.0/fval
    OScope.write('HORIZONTAL:SCALE '+str(1.0/fval)) #Adjust the horizontal scale to 10ms/div
    time.sleep(3)  

##     OScope.write(':SAV:WAVE ALL, "E:/freq_C1V_C2I'+str(index)+'.csv"') 
    OScope.write(':SAV:WAVE ALL, "E:/test2_'+str(fval)+'Hz.csv"') 
    time.sleep(2)           #wait momentarily to let system to save data
##     index = index+1

FreqGen.write('OUTPut OFF')     # Turn Function Generator off
## SrcMeter.write(':OUTP OFF')     # Turn off the source output

## OScope.write(':CH2:OFFS 0')

# Display elapsed time
print "Elapsed time(s):"
print (time.time() - start)

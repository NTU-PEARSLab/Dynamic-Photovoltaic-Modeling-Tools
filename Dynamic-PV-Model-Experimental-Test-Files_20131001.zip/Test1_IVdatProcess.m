% Data processing for Test 1, data collected through Python code.
% Outputs I and V vectors as a .mat file
% Katherine A. Kim
% University of Illinois at Urbana-Champaign
% 1/31/2013

clear all
close all
clc

I = importdata('I.dat');
I = -I;
V = importdata('V.dat');
P = I.*V;

figure(1)
plot(V,I,'-b.','linewidth',2)
xlabel('Voltage (V)')
ylabel('Current (A)')
grid on

% figure(2)
% plot(V,P,'-m.','linewidth',2)
% xlabel('Voltage (V)')
% ylabel('Power (W)')
% grid on
% 
% figure(3)
% plot(I,P,'-r^','linewidth',2)
% xlabel('Current (A)')
% ylabel('Power (W)')
% grid on

Idat = I;
Vdat = V;

save('IVdat','Idat','Vdat');
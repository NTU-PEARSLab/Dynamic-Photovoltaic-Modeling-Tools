# Test 3 of 3 - PV AC Analysis Voltage Sweep
# Finds Rp and Cp values
# Katherine A. Kim, Chenyang Xu, Lei Jin, Philip T. Krein
# Special thanks to Boris Dieseldorf his help with Python
# University of Illinois at Urbana-Champaign
# 2/1/2013
# Physical Setup: 
# 1) Programmable Power Supply (Keithley 2420)
# 2) Function Generator with Transformer (Agilent 3325A)
# 2) Oscilliscope (Textronix MSO4034)

# setup communication with instrument
from visa import*
import time
import datetime

#Check connections with instruments
SrcMeter = instrument("GPIB::2")        # Keithley 2420 SourceMeter
print "Equipment GPIB 1:"               # confirm connection, ask for it's name
print SrcMeter.ask('*IDN?')

import datetime
FreqGen = instrument("GPIB::1")         # Agilent 33250A Function Generator
print "Equipment GPIB 1:"               # confirm connection, ask for it's name
print FreqGen.ask('*IDN?')

OScope = instrument("USB0::0x0699::0x0401::C000784")    #Tekronix MSO4034
print "Equipment USB:"                  # confirm connection, ask for it's name
print OScope.ask('*IDN?')

# configure meter for current mode
SrcMeter.write('*RST')                  #Reset GPIB Defaults
SrcMeter.write(':SOUR:FUNC CURR')       #Set current mode
SrcMeter.write(':SOUR:CURR:MODE FIX')
SrcMeter.write(':SOUR:CURR:RANG 0.5')   #Set acceptable current range
SrcMeter.write(':SENS:VOLT:PROT 30')    #Set acceptable voltage range
SrcMeter.write(':SENS:FUNC "VOLT"')     #Set-up voltage measurement

SrcMeter.write(':SOUR:CURR:LEV 0')      #Initially set to 0 A

FreqGen.write('*RST')                  #Reset GPIB Defaults

# Current Measurement Points
## Iset = range(-300,46,15) #Desired testing range in mA
Iset = range(300,-401,-50) #Desired testing range in mA
## Iset = [-300, -250, -200, -150, -125, -100, -75, -50, -40, -30, -20, -15, -10, -5, 0, 10, 20, 40, 60]
print Iset


print '500 Hz Measurements'
# open file for saving data
I = open('I500Hz.dat','w')
V = open('V500Hz.dat','w')

start = time.time()     #start timing from this point

index = 1;
# 500 Hz Current Sweep for PV
FreqGen.write('APPL:SIN 500, 1.2, 0')       #Set current mode
OScope.write('HORIZONTAL:SCALE 1E-3') #Adjust the horizontal scale to 10ms/div
FreqGen.write('OUTPut ON')      # Turn on function generator
SrcMeter.write(':OUTP ON')
# set and then measure I and V for each point
for Ival in Iset:
    Ival_fl = float(Ival)/1000  #convert into A
    
    SrcMeter.write(':SOUR:CURR:LEV '+str(Ival_fl))      #Set meter I value
    OScope.write(':CH2:OFFS '+str(-Ival_fl)) #Adjust the Ch2 offset to center at zero
    time.sleep(2)  
    
    meterout = SrcMeter.ask(':READ?')   #Read back string
    meterV = float(meterout[0:13])      #first measurement is voltage
    meterI = float(meterout[14:27])     #second measurement is current
    
    if meterV >=-30:
        OScope.write(':SAV:WAVE ALL, "E:/test3_500hz_'+str(index)+'.csv"') 
        time.sleep(2)           #wait momentarily to let system settle
        
        # Store values in text file with space deliminator
        I.write(str(meterI)+' ')
        V.write(str(meterV)+' ')
        index = index+1
        
        # Debugging: print-out values
        print 'V: '+str(meterV)
        print 'I: '+str(meterI)
        print ' '
    #end if

SrcMeter.write(":OUTP OFF")     #Turn off the source output
OScope.write(':CH2:OFFS 0')
I.close()
V.close()


# 100 kHz Current Sweep for PV
print '100 kHz Measurements'
FreqGen.write('APPL:SIN 100e3, 1.2, 0')       #Set current mode
OScope.write('HORIZONTAL:SCALE 4E-6') #Adjust the horizontal scale to 10us/div
SrcMeter.write(':OUTP ON')

# open file for saving data
I = open('I100kHz.dat','w')
V = open('V100kHz.dat','w')

## start = time.time()     #start timing from this point

index = 1;
# set and then measure I and V for each point
for Ival in Iset:
    Ival_fl = float(Ival)/1000  #convert into A
    
    SrcMeter.write(':SOUR:CURR:LEV '+str(Ival_fl))      #Set meter I value
    OScope.write(':CH2:OFFS '+str(-Ival_fl)) #Adjust the Ch2 offset to center at zero
    time.sleep(2.5)           #use time to change scale
    
    meterout = SrcMeter.ask(':READ?')   #Read back string
    meterV = float(meterout[0:13])      #first measurement is voltage
    meterI = float(meterout[14:27])     #second measurement is current
    
    if meterV >=-30:
        OScope.write(':SAV:WAVE ALL, "E:/test3_100khz_'+str(index)+'.csv"') 
        time.sleep(2.5)           #wait momentarily to let system settle
        
        # Store values in text file with space deliminator
        I.write(str(meterI)+' ')
        V.write(str(meterV)+' ')
        index = index+1
        
        # Debugging: print-out values
        print 'V: '+str(meterV)
        print 'I: '+str(meterI)
        print ' '
    #end if

SrcMeter.write(":OUTP OFF")     #Turn off the source output
FreqGen.write('OUTPut OFF')     # Turn Function Generator off
OScope.write(':CH2:OFFS 0')

I.close()
V.close()

## FreqGen.write('APPL:SIN 500, 2, 0')       #Set back to 50hz

# Display elapsed time
print "Elapsed time(s):"
print (time.time() - start)
